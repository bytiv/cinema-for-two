/**
 * save-ingest-movie.ts
 *
 * Called server-side once a torrent job reaches stage "Ready".
 * Inserts the movie row into Supabase (matching the direct-upload schema)
 * and back-fills torrent_jobs.movie_id.
 *
 * blob_url from the Python container is the SAS URL stripped of its query
 * string — i.e. the bare https://<account>.blob.core.windows.net/<container>/<blobName>
 * The blob_name is everything after the container segment, which for ingest
 * jobs now matches the normal upload pattern: {userId}/{timestamp}-{slug}.{ext}
 */

import { createServiceRoleClient } from '@/lib/supabase/server';
import { generateReadSasUrl, CONTAINERS } from '@/lib/azure-blob';
import type { TorrentJob } from '@/types';

export interface SaveIngestMovieParams {
  job:          TorrentJob;
  userId:       string;
  title:        string;
  description?: string;
  posterUrl?:   string;
  quality?:     '480p' | '720p' | '1080p' | '4K' | null;
  subtitles?:   { label: string; lang: string; url: string }[];
}

export interface SaveIngestMovieResult {
  movieId: string;
  blobUrl: string;
}

/**
 * Probes the blob for file size (HEAD) and duration (ffprobe via SAS URL).
 */
async function probeBlobMeta(
  blobName: string,
): Promise<{ fileSize: number; duration: number | null }> {
  const sasUrl = generateReadSasUrl(CONTAINERS.movies, blobName, 1);

  let fileSize = 0;
  try {
    const head = await fetch(sasUrl, { method: 'HEAD' });
    const cl   = parseInt(head.headers.get('content-length') ?? '0', 10);
    if (!isNaN(cl)) fileSize = cl;
  } catch {}

  let duration: number | null = null;
  try {
    const ffmpeg  = (await import('fluent-ffmpeg')).default;
    const ffprobe = await import('@ffprobe-installer/ffprobe');
    ffmpeg.setFfprobePath(ffprobe.path);
    duration = await new Promise<number | null>((resolve) => {
      ffmpeg.ffprobe(sasUrl, (err, metadata) => {
        if (err) { resolve(null); return; }
        const secs = metadata?.format?.duration;
        resolve(typeof secs === 'number' && isFinite(secs) && secs > 0 ? Math.round(secs) : null);
      });
    });
  } catch {
    duration = null;
  }

  return { fileSize, duration };
}

export async function saveIngestMovie(
  params: SaveIngestMovieParams,
): Promise<SaveIngestMovieResult> {
  const { job, userId, title, description, posterUrl, quality, subtitles } = params;

  if (!job.blob_url) {
    throw new Error('Job is Ready but has no blob_url — cannot save movie');
  }

  const supabase = createServiceRoleClient();

  // ── Derive blob_name from blob_url ────────────────────────────────────────
  //
  // blob_url is the clean URL (no SAS query string):
  //   https://<account>.blob.core.windows.net/movies/{userId}/{ts}-{slug}.{ext}
  //
  // We need the path after "/movies/" — that is the blob_name as stored in
  // the normal upload flow: "{userId}/{ts}-{slug}.{ext}"
  //
  // Split on "/movies/" and take everything after it.
  const afterContainer = job.blob_url.split('/movies/')[1];
  if (!afterContainer) {
    throw new Error(`Unexpected blob_url format — cannot extract blob_name: ${job.blob_url}`);
  }

  // blob_url has no extension (SAS was signed for the base path).
  // blob_ext carries the real extension discovered after download, e.g. ".mkv".
  const ext         = (job as any).blob_ext ?? '.mp4';
  const extClean    = ext.replace('.', '').toLowerCase();
  const blobName    = `${afterContainer}${ext}`;        // e.g. "abc/1712345678901-interstellar.mkv"
  const fullBlobUrl = `${job.blob_url}${ext}`;

  // ── Derive format ─────────────────────────────────────────────────────────
  const format = ['mp4', 'mkv', 'avi', 'mov', 'wmv', 'm4v', 'ts'].includes(extClean) ? extClean : 'mp4';

  // ── Probe blob ────────────────────────────────────────────────────────────
  const { fileSize, duration } = await probeBlobMeta(blobName);

  // ── Insert movie row ──────────────────────────────────────────────────────
  const { data: movie, error: movieError } = await supabase
    .from('movies')
    .insert({
      title:         title.trim(),
      description:   description?.trim() ?? null,
      blob_url:      fullBlobUrl,
      blob_name:     blobName,
      poster_url:    posterUrl ?? null,
      file_size:     fileSize,
      format,
      quality:       quality ?? null,
      duration,
      subtitles:     subtitles ?? [],
      ingest_method: 'torrent',
      info_hash:     job.info_hash,
      ingest_job_id: job.job_id,
      uploaded_by:   userId,
    })
    .select('id, blob_url')
    .single();

  if (movieError || !movie) {
    throw new Error(`Failed to insert movie: ${movieError?.message}`);
  }

  // ── Back-fill torrent_jobs.movie_id ───────────────────────────────────────
  const { error: jobError } = await supabase.rpc('upsert_torrent_job', {
    p_job_id:       job.job_id,
    p_requested_by: userId,
    p_info_hash:    job.info_hash,
    p_stage:        'Ready',
    p_blob_url:     job.blob_url,
    p_movie_id:     movie.id,
  });

  if (jobError) {
    console.error(`[save-ingest-movie] back-fill movie_id: ${jobError.message}`);
  }

  return { movieId: movie.id, blobUrl: movie.blob_url };
}