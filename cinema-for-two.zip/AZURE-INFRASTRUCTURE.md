# ═══════════════════════════════════════════════════════════════
# 🎬 CinemaForTwo — Azure Infrastructure Reference
# ═══════════════════════════════════════════════════════════════
# Keep this file in your project root for reference.
# DO NOT commit to public repos — contains sensitive info.
# ═══════════════════════════════════════════════════════════════


# ───────────────────────────────────────────────────────────────
# AZURE SERVICE PRINCIPAL
# ───────────────────────────────────────────────────────────────
# Name:         cinema-ingest-sp
# Purpose:      Manages ACI container lifecycle (create, read, delete)
#               for per-user ephemeral torrent ingest containers.
#
# App ID:       93591c77-72b7-401c-ab52-a256b5dccfbe
# Object ID:    ff6277de-2b5f-47b4-b864-7c39ce8f860f
# Tenant ID:    6bf5a45a-642d-43d7-9a68-5841abc5cf92
# Secret:       sai8Q~uB0bMxghDz61VaEpQHX4zjDeB.6~jFpaye
#
# ⚠️  Secret expiry: Check in Azure Portal → App Registrations
#     → cinema-ingest-sp → Certificates & secrets


# ───────────────────────────────────────────────────────────────
# CUSTOM ROLE: CinemaIngestOperator
# ───────────────────────────────────────────────────────────────
# Role ID:      d45fd827-e0e6-4b25-ac35-e68ea5c5c59e
# Scope:        /subscriptions/3706a957-028d-4d64-aed3-0e35712012c1/resourceGroups/cinema-ingest-rg
#
# Permissions:
#   ✓ Microsoft.ContainerInstance/containerGroups/read
#   ✓ Microsoft.ContainerInstance/containerGroups/write      (create/update)
#   ✓ Microsoft.ContainerInstance/containerGroups/delete
#   ✓ Microsoft.ContainerInstance/containerGroups/start/action
#   ✓ Microsoft.ContainerInstance/containerGroups/stop/action
#   ✓ Microsoft.Resources/subscriptions/resourceGroups/read


# ───────────────────────────────────────────────────────────────
# AZURE SUBSCRIPTION & RESOURCE GROUP
# ───────────────────────────────────────────────────────────────
# Subscription ID:   3706a957-028d-4d64-aed3-0e35712012c1
# Resource Group:    cinema-ingest-rg
# Location:          Central India


# ───────────────────────────────────────────────────────────────
# CONTAINER ARCHITECTURE (Per-User Ephemeral)
# ───────────────────────────────────────────────────────────────
# Docker Image:      belal0gebaly/cinema-ingest:latest (v8.0.0)
# Container Naming:  ingest-{8-char-hex}  (e.g., ingest-a1b2c3d4)
# CPU:               0.5 cores  (env: CONTAINER_CPU)
# Memory:            1 GB       (env: CONTAINER_MEMORY)
# Idle Timeout:      300s / 5 min (env: IDLE_SHUTDOWN_SECONDS)
# Self-Cleanup:      Container DELETES itself from Azure after idle timeout
# Restart Policy:    Never
#
# Flow:
#   1. User submits torrent → Next.js checks for existing running container
#   2. If found & healthy → reuse it (send new job to same container)
#   3. If not found → create new ACI with unique name + fresh HMAC secret
#   4. Container runs job(s), then self-deletes after 5 min idle
#
# Each ingest_jobs row in Supabase tracks:
#   container_name, container_ip, hmac_secret, container_rg


# ───────────────────────────────────────────────────────────────
# .env.local VARIABLES (for Next.js)
# ───────────────────────────────────────────────────────────────
# AZURE_SP_CLIENT_ID=93591c77-72b7-401c-ab52-a256b5dccfbe
# AZURE_SP_CLIENT_SECRET=sai8Q~uB0bMxghDz61VaEpQHX4zjDeB.6~jFpaye
# AZURE_SP_TENANT_ID=6bf5a45a-642d-43d7-9a68-5841abc5cf92
# AZURE_SUBSCRIPTION_ID=3706a957-028d-4d64-aed3-0e35712012c1
# AZURE_RESOURCE_GROUP=cinema-ingest-rg
# CONTAINER_CPU=0.5
# CONTAINER_MEMORY=1
# IDLE_SHUTDOWN_SECONDS=300


# ───────────────────────────────────────────────────────────────
# USEFUL AZURE CLI COMMANDS
# ───────────────────────────────────────────────────────────────
#
# List all running containers:
#   az container list --resource-group cinema-ingest-rg --output table
#
# Check a specific container's logs:
#   az container logs --resource-group cinema-ingest-rg --name ingest-XXXXXXXX
#
# Delete a specific container:
#   az container delete --resource-group cinema-ingest-rg --name ingest-XXXXXXXX --yes
#
# Delete ALL containers in the resource group:
#   az container list --resource-group cinema-ingest-rg --query "[].name" -o tsv | xargs -I {} az container delete --resource-group cinema-ingest-rg --name {} --yes
#
# Check role assignments for the service principal:
#   az role assignment list --assignee 93591c77-72b7-401c-ab52-a256b5dccfbe --scope /subscriptions/3706a957-028d-4d64-aed3-0e35712012c1/resourceGroups/cinema-ingest-rg --output table
#
# Check role permissions:
#   az role definition list --name "CinemaIngestOperator" --output json --query "[0].permissions[0].actions"
#
# Rotate service principal secret:
#   az ad sp credential reset --id 93591c77-72b7-401c-ab52-a256b5dccfbe
#   (then update AZURE_SP_CLIENT_SECRET in .env.local and Vercel)
